public class RandomWord {
    public static void main(String[] args) {
        int length = args.length;
        String champion = "";
        for (int index = 0; index < length; index++) {
            int r = (int) (Math.random() * (index + 1));
            champion = args[r];
        }
        System.out.println(champion);
    }
}
